import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import api from '../services/api';
import { Project } from '../types';
import { FiPlus, FiEdit, FiTrash2, FiEye, FiSearch, FiFolder, FiUsers, FiCheckSquare, FiGrid, FiList } from 'react-icons/fi';
import toast from 'react-hot-toast';
import Skeleton from '../components/Skeleton';

const StatusBadge = ({ status, t }: { status: string; t: any }) => {
  const map: Record<string, string> = {
    active: 'badge-active',
    completed: 'badge-completed',
    suspended: 'badge-suspended',
  };
  const labels: Record<string, string> = {
    active: t('project.active'),
    completed: t('project.completed'),
    suspended: t('project.suspended'),
  };
  const dots: Record<string, string> = {
    active: 'bg-emerald-500',
    completed: 'bg-blue-500',
    suspended: 'bg-amber-500',
  };
  return (
    <span className={`badge ${map[status] || 'badge'}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${dots[status] || 'bg-gray-400'}`} />
      {labels[status] || status}
    </span>
  );
};

const Projects = () => {
  const { t } = useTranslation();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  useEffect(() => { fetchProjects(); }, []);

  const fetchProjects = async () => {
    try {
      const res = await api.get('/projects');
      setProjects(res.data);
    } catch {
      toast.error(t('projects.fetchError'));
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm(t('common.confirmDelete'))) return;
    try {
      await api.delete(`/projects/${id}`);
      toast.success(t('projects.deleteSuccess'));
      fetchProjects();
    } catch {
      toast.error(t('projects.deleteError'));
    }
  };

  const filtered = projects.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) ||
      (p.description?.toLowerCase().includes(search.toLowerCase()) ?? false);
    const matchStatus = statusFilter === 'all' || p.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const stats = [
    { label: t('dashboard.totalProjects'), value: projects.length, color: 'from-indigo-500 to-violet-500', bg: 'bg-indigo-50 dark:bg-indigo-900/20', icon: FiFolder, iconColor: 'text-indigo-600' },
    { label: t('project.active'), value: projects.filter(p => p.status === 'active').length, color: 'from-emerald-500 to-teal-500', bg: 'bg-emerald-50 dark:bg-emerald-900/20', icon: FiCheckSquare, iconColor: 'text-emerald-600' },
    { label: t('project.completed'), value: projects.filter(p => p.status === 'completed').length, color: 'from-blue-500 to-cyan-500', bg: 'bg-blue-50 dark:bg-blue-900/20', icon: FiCheckSquare, iconColor: 'text-blue-600' },
    { label: t('projects.searchResults'), value: filtered.length, color: 'from-violet-500 to-pink-500', bg: 'bg-violet-50 dark:bg-violet-900/20', icon: FiSearch, iconColor: 'text-violet-600' },
  ];

  if (loading) return (
    <div className="space-y-6">
      <div className="flex justify-between"><Skeleton className="h-9 w-40" /><Skeleton className="h-9 w-32" /></div>
      <div className="grid grid-cols-4 gap-4">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-20 rounded-2xl" />)}</div>
      <div className="grid grid-cols-3 gap-4">{[...Array(6)].map((_, i) => <Skeleton key={i} className="h-44 rounded-2xl" />)}</div>
    </div>
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="page-title">{t('projects.title')}</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{projects.length} مشروع إجمالاً</p>
        </div>
        <Link to="/projects/new" className="btn-primary inline-flex items-center gap-2">
          <FiPlus size={18} /> {t('projects.newProject')}
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s, i) => (
          <div key={i} className={`card p-5 animate-fade-in delay-${i + 1}`}>
            <div className="flex items-center justify-between mb-3">
              <div className={`stat-icon ${s.bg}`}>
                <s.icon size={20} className={s.iconColor} />
              </div>
              <span className="text-3xl font-black text-gray-900 dark:text-white">{s.value}</span>
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">{s.label}</p>
            <div className="progress-bar mt-3">
              <div className={`progress-fill bg-gradient-to-r ${s.color}`} style={{ width: projects.length ? `${(s.value / projects.length) * 100}%` : '0%' }} />
            </div>
          </div>
        ))}
      </div>

      {/* Search & Filters */}
      <div className="card p-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 relative">
            <FiSearch className="absolute right-3.5 top-3.5 text-gray-400" size={16} />
            <input
              type="text"
              placeholder={t('common.search') + '...'}
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="input-field pr-10"
            />
          </div>
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="input-field w-full sm:w-44"
          >
            <option value="all">{t('common.all')}</option>
            <option value="active">{t('project.active')}</option>
            <option value="completed">{t('project.completed')}</option>
            <option value="suspended">{t('project.suspended')}</option>
          </select>
          <div className="flex items-center border border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden">
            <button onClick={() => setViewMode('grid')} className={`p-2.5 px-3 transition ${viewMode === 'grid' ? 'bg-indigo-600 text-white' : 'text-gray-500 hover:bg-gray-50 dark:hover:bg-gray-700'}`}><FiGrid size={16} /></button>
            <button onClick={() => setViewMode('list')} className={`p-2.5 px-3 transition ${viewMode === 'list' ? 'bg-indigo-600 text-white' : 'text-gray-500 hover:bg-gray-50 dark:hover:bg-gray-700'}`}><FiList size={16} /></button>
          </div>
        </div>
      </div>

      {/* Projects */}
      {filtered.length === 0 ? (
        <div className="card p-16 text-center">
          <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <FiFolder size={28} className="text-gray-400" />
          </div>
          <p className="text-gray-500 dark:text-gray-400 font-medium">{t('projects.noProjects')}</p>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((project, i) => (
            <div key={project.id} className={`card-hover p-5 animate-fade-in delay-${Math.min(i + 1, 5)}`}>
              <div className="flex justify-between items-start mb-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-100 to-violet-100 dark:from-indigo-900/40 dark:to-violet-900/40 flex items-center justify-center">
                  <FiFolder size={18} className="text-indigo-600 dark:text-indigo-400" />
                </div>
                <StatusBadge status={project.status} t={t} />
              </div>
              <h3 className="text-base font-bold text-gray-900 dark:text-white mb-1.5">{project.name}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-2 mb-4">{project.description}</p>
              <div className="flex items-center gap-4 text-xs text-gray-500 dark:text-gray-400 mb-4">
                <span className="flex items-center gap-1.5"><FiCheckSquare size={13} className="text-indigo-400" />{t('projects.tasksCount', { count: project._count?.tasks || 0 })}</span>
                <span className="flex items-center gap-1.5"><FiUsers size={13} className="text-violet-400" />{t('projects.membersCount', { count: project._count?.members || 0 })}</span>
              </div>
              <div className="flex items-center justify-end gap-1.5 pt-3 border-t border-gray-100 dark:border-gray-700">
                <Link to={`/projects/${project.id}`} className="p-2 text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition" title={t('common.view')}><FiEye size={15} /></Link>
                <Link to={`/projects/${project.id}/edit`} className="p-2 text-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-lg transition" title={t('common.edit')}><FiEdit size={15} /></Link>
                <button onClick={() => handleDelete(project.id)} className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition" title={t('common.delete')}><FiTrash2 size={15} /></button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="card overflow-hidden">
          {filtered.map((project, i) => (
            <div key={project.id} className={`flex items-center gap-4 px-5 py-4 hover:bg-gray-50 dark:hover:bg-gray-700/40 transition ${i !== 0 ? 'border-t border-gray-100 dark:border-gray-700' : ''}`}>
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-100 to-violet-100 dark:from-indigo-900/40 dark:to-violet-900/40 flex items-center justify-center flex-shrink-0">
                <FiFolder size={15} className="text-indigo-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-gray-900 dark:text-white text-sm">{project.name}</p>
                <p className="text-xs text-gray-500 truncate">{project.description}</p>
              </div>
              <StatusBadge status={project.status} t={t} />
              <div className="flex items-center gap-1">
                <Link to={`/projects/${project.id}`} className="p-2 text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition"><FiEye size={14} /></Link>
                <Link to={`/projects/${project.id}/edit`} className="p-2 text-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-lg transition"><FiEdit size={14} /></Link>
                <button onClick={() => handleDelete(project.id)} className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition"><FiTrash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Projects;

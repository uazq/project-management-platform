import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuthStore } from '../store/authStore';
import { FiLogIn, FiEye, FiEyeOff, FiUser, FiLock } from 'react-icons/fi';

const Login = () => {
  const { t } = useTranslation();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const { login, isLoading } = useAuthStore();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await login(username, password);
    navigate('/');
  };

  return (
    <div className="min-h-screen flex bg-slate-50 dark:bg-gray-950">
      {/* Left decorative panel */}
      <div className="hidden lg:flex flex-col justify-between w-1/2 bg-gradient-to-br from-indigo-600 via-violet-600 to-purple-700 p-12 relative overflow-hidden">
        {/* Decorative circles */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2" />
        <div className="absolute top-1/2 left-1/2 w-48 h-48 bg-white/5 rounded-full -translate-x-1/2 -translate-y-1/2" />
        
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-sm">
              <FiUser size={20} className="text-white" />
            </div>
            <span className="text-white font-bold text-xl">مشروعي</span>
          </div>
        </div>

        <div className="relative z-10">
          <h2 className="text-4xl font-black text-white leading-tight mb-4">
            إدارة مشاريعك
            <br />
            <span className="text-white/70">بكل سهولة</span>
          </h2>
          <p className="text-white/60 text-lg leading-relaxed">
            منصة متكاملة لإدارة المشاريع والمهام والفرق بكفاءة عالية
          </p>
        </div>

        <div className="relative z-10 grid grid-cols-3 gap-4">
          {[
            { label: 'مشروع', value: '120+' },
            { label: 'مستخدم', value: '500+' },
            { label: 'مهمة منجزة', value: '3k+' },
          ].map((s) => (
            <div key={s.label} className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 border border-white/10">
              <p className="text-2xl font-black text-white">{s.value}</p>
              <p className="text-white/60 text-sm">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Right login form */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-md animate-fade-in">
          {/* Mobile logo */}
          <div className="lg:hidden flex items-center gap-2 justify-center mb-8">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <FiUser size={18} className="text-white" />
            </div>
            <span className="text-2xl font-black gradient-text">مشروعي</span>
          </div>

          <div className="card p-8 shadow-xl shadow-gray-200/60 dark:shadow-black/30">
            <div className="mb-8">
              <h1 className="text-2xl font-black text-gray-900 dark:text-white mb-1">مرحباً بعودتك 👋</h1>
              <p className="text-gray-500 dark:text-gray-400 text-sm">{t('login.subtitle')}</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="label">{t('login.username')}</label>
                <div className="relative">
                  <FiUser className="absolute right-3 top-3.5 text-gray-400" size={16} />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="input-field pr-10"
                    placeholder="اسم المستخدم"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="label">{t('login.password')}</label>
                <div className="relative">
                  <FiLock className="absolute right-3 top-3.5 text-gray-400" size={16} />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="input-field pr-10 pl-10"
                    placeholder="••••••••"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3 top-3.5 text-gray-400 hover:text-gray-600 transition"
                  >
                    {showPassword ? <FiEyeOff size={16} /> : <FiEye size={16} />}
                  </button>
                </div>
              </div>

              <div className="flex justify-end">
                <Link to="/forgot-password" className="text-sm text-indigo-600 hover:text-indigo-700 font-semibold">
                  {t('login.forgotPassword')}
                </Link>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full btn-primary flex items-center justify-center gap-2 py-3 text-base"
              >
                <FiLogIn size={18} />
                {isLoading ? t('common.loading') : t('login.login')}
              </button>
            </form>

            <p className="mt-6 text-center text-sm text-gray-500 dark:text-gray-400">
              {t('login.noAccount')}{' '}
              <Link to="/register" className="text-indigo-600 hover:text-indigo-700 font-bold">
                {t('login.register')}
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;

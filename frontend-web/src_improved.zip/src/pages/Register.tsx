import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuthStore } from '../store/authStore';
import { FiUserPlus, FiUser, FiMail, FiLock, FiEye, FiEyeOff } from 'react-icons/fi';

const Register = () => {
  const { t } = useTranslation();
  const [formData, setFormData] = useState({ fullName: '', username: '', email: '', password: '', confirmPassword: '' });
  const [passwordError, setPasswordError] = useState('');
  const [showPass, setShowPass] = useState(false);
  const { register, isLoading } = useAuthStore();
  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) { setPasswordError(t('register.passwordMismatch')); return; }
    setPasswordError('');
    await register({ fullName: formData.fullName, username: formData.username, email: formData.email, password: formData.password });
    navigate('/');
  };

  const fields = [
    { name: 'fullName', label: t('register.fullName'), type: 'text', icon: FiUser, placeholder: 'الاسم الكامل' },
    { name: 'username', label: t('register.username'), type: 'text', icon: FiUser, placeholder: 'اسم المستخدم' },
    { name: 'email', label: t('register.email'), type: 'email', icon: FiMail, placeholder: 'example@mail.com' },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-gray-950 py-10 px-4">
      <div className="w-full max-w-md animate-fade-in">
        {/* Logo */}
        <div className="flex items-center gap-2 justify-center mb-6">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/30">
            <FiUserPlus size={18} className="text-white" />
          </div>
          <span className="text-2xl font-black gradient-text">{t('common.appName')}</span>
        </div>

        <div className="card p-8 shadow-xl shadow-gray-200/60 dark:shadow-black/30">
          <div className="mb-6">
            <h1 className="text-2xl font-black text-gray-900 dark:text-white mb-1">إنشاء حساب جديد ✨</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">{t('register.subtitle')}</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {fields.map(f => (
              <div key={f.name}>
                <label className="label">{f.label}</label>
                <div className="relative">
                  <f.icon className="absolute right-3.5 top-3.5 text-gray-400" size={15} />
                  <input
                    type={f.type}
                    name={f.name}
                    value={(formData as any)[f.name]}
                    onChange={handleChange}
                    className="input-field pr-10"
                    placeholder={f.placeholder}
                    required
                  />
                </div>
              </div>
            ))}

            <div>
              <label className="label">{t('register.password')}</label>
              <div className="relative">
                <FiLock className="absolute right-3.5 top-3.5 text-gray-400" size={15} />
                <input
                  type={showPass ? 'text' : 'password'}
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  className="input-field pr-10 pl-10"
                  placeholder="••••••••"
                  required
                />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute left-3.5 top-3.5 text-gray-400 hover:text-gray-600">
                  {showPass ? <FiEyeOff size={15} /> : <FiEye size={15} />}
                </button>
              </div>
            </div>

            <div>
              <label className="label">{t('register.confirmPassword')}</label>
              <div className="relative">
                <FiLock className="absolute right-3.5 top-3.5 text-gray-400" size={15} />
                <input
                  type="password"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  className="input-field pr-10"
                  placeholder="••••••••"
                  required
                />
              </div>
              {passwordError && <p className="text-red-500 text-xs mt-1.5 font-medium">{passwordError}</p>}
            </div>

            <button type="submit" disabled={isLoading} className="w-full btn-primary flex items-center justify-center gap-2 py-3 text-base mt-2">
              <FiUserPlus size={18} />
              {isLoading ? t('common.loading') : t('register.register')}
            </button>
          </form>

          <p className="mt-5 text-center text-sm text-gray-500 dark:text-gray-400">
            {t('register.haveAccount')}{' '}
            <Link to="/login" className="text-indigo-600 hover:text-indigo-700 font-bold">{t('login.login')}</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;

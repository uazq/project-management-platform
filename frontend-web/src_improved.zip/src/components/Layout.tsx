import { ReactNode, useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { 
  FiHome, FiFolder, FiUsers, FiUser, FiLogOut, 
  FiMenu, FiX, FiBell, FiMoon, FiSun, FiClock, FiGlobe,
  FiChevronRight
} from 'react-icons/fi';
import { useTranslation } from 'react-i18next';
import socket from '../services/socket';

interface LayoutProps { children: ReactNode; }
interface Notification {
  id: string; message: string; projectId?: number; read: boolean; timestamp: Date;
}

const Layout = ({ children }: LayoutProps) => {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();
  const { t, i18n } = useTranslation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem('darkMode');
    return saved ? JSON.parse(saved) : false;
  });
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    if (darkMode) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
    localStorage.setItem('darkMode', JSON.stringify(darkMode));
  }, [darkMode]);

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
    document.documentElement.dir = lng === 'ar' ? 'rtl' : 'ltr';
  };

  const handleLogout = () => { logout(); navigate('/login'); };
  const isActive = (path: string) => location.pathname === path;

  const navLinks = [
    { path: '/', label: t('common.dashboard'), icon: FiHome },
    { path: '/projects', label: t('common.projects'), icon: FiFolder },
    { path: '/activities', label: t('common.activities'), icon: FiClock },
    { path: '/profile', label: t('common.profile'), icon: FiUser },
    { path: '/users', label: t('common.users'), icon: FiUsers, adminOnly: true },
  ];

  const unreadCount = notifications.filter(n => !n.read).length;
  const currentPage = navLinks.find(l => isActive(l.path));

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-gray-950 flex" dir={i18n.language === 'ar' ? 'rtl' : 'ltr'}>
      
      {/* Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* ===== SIDEBAR ===== */}
      <aside className={`
        fixed inset-y-0 z-50 w-64 bg-white dark:bg-gray-900 
        border-l border-gray-100 dark:border-gray-800
        flex flex-col transition-transform duration-300 ease-in-out
        lg:relative lg:translate-x-0
        ${i18n.language === 'ar' ? 'right-0' : 'left-0'}
        ${sidebarOpen 
          ? 'translate-x-0' 
          : i18n.language === 'ar' ? 'translate-x-full' : '-translate-x-full'
        }
      `}>
        {/* Logo */}
        <div className="flex items-center justify-between px-5 h-16 border-b border-gray-100 dark:border-gray-800">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <FiFolder size={16} className="text-white" />
            </div>
            <span className="text-lg font-bold gradient-text">{t('common.appName')}</span>
          </Link>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-1.5 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100">
            <FiX size={18} />
          </button>
        </div>

        {/* User mini card */}
        <div className="mx-3 mt-4 p-3 bg-gradient-to-br from-indigo-50 to-violet-50 dark:from-indigo-900/20 dark:to-violet-900/20 rounded-2xl border border-indigo-100 dark:border-indigo-800/30">
          <div className="flex items-center gap-3">
            {user?.profilePicture ? (
              <img src={`http://localhost:5000${user.profilePicture}`} className="w-9 h-9 rounded-xl object-cover ring-2 ring-indigo-200" />
            ) : (
              <div className="w-9 h-9 bg-gradient-to-br from-indigo-500 to-violet-600 rounded-xl flex items-center justify-center text-white font-bold text-sm shadow-md">
                {user?.fullName?.[0]?.toUpperCase() || 'U'}
              </div>
            )}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-gray-800 dark:text-white truncate">{user?.fullName}</p>
              <p className="text-xs text-indigo-500 dark:text-indigo-400 font-medium truncate">{user?.role}</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-4 px-3">
          <p className="text-xs font-bold text-gray-400 dark:text-gray-600 uppercase tracking-widest px-4 mb-3">القائمة</p>
          {navLinks.map(link => {
            if (link.adminOnly && user?.role !== 'admin') return null;
            const active = isActive(link.path);
            return (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setSidebarOpen(false)}
                className={active ? 'sidebar-link-active' : 'sidebar-link'}
              >
                <link.icon size={18} />
                <span>{link.label}</span>
                {active && <FiChevronRight size={14} className={`${i18n.language === 'ar' ? 'mr-auto rotate-180' : 'ml-auto'}`} />}
              </Link>
            );
          })}
        </nav>

        {/* Logout */}
        <div className="p-3 border-t border-gray-100 dark:border-gray-800">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all font-semibold text-sm"
          >
            <FiLogOut size={18} />
            <span>{t('common.logout')}</span>
          </button>
        </div>
      </aside>

      {/* ===== MAIN CONTENT ===== */}
      <div className="flex-1 flex flex-col min-h-screen min-w-0">
        
        {/* Top Header */}
        <header className="sticky top-0 z-30 bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-b border-gray-100 dark:border-gray-800">
          <div className="flex items-center justify-between px-4 lg:px-8 h-16">
            
            {/* Left: Menu + Page Title */}
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-xl transition"
              >
                <FiMenu size={20} />
              </button>
              <div>
                <h1 className="text-lg font-bold text-gray-900 dark:text-white hidden lg:block">
                  {currentPage?.label || t('common.dashboard')}
                </h1>
                <Link to="/" className="text-xl font-bold gradient-text lg:hidden">{t('common.appName')}</Link>
              </div>
            </div>

            {/* Right: Actions */}
            <div className="flex items-center gap-2">
              {/* Language */}
              <button 
                onClick={() => changeLanguage(i18n.language === 'ar' ? 'en' : 'ar')}
                className="p-2 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-xl transition-all font-bold text-sm"
                title="تغيير اللغة"
              >
                <FiGlobe size={18} />
              </button>

              {/* Dark Mode */}
              <button 
                onClick={() => setDarkMode(!darkMode)}
                className="p-2 text-gray-500 hover:text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-900/20 rounded-xl transition-all"
              >
                {darkMode ? <FiSun size={18} /> : <FiMoon size={18} />}
              </button>

              {/* Notifications */}
              <div className="relative">
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative p-2 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-xl transition-all"
                >
                  <FiBell size={18} />
                  {unreadCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full ring-2 ring-white dark:ring-gray-900" />
                  )}
                </button>

                {showNotifications && (
                  <div className="absolute top-12 left-0 w-80 bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700 z-50 animate-fade-in overflow-hidden">
                    <div className="flex items-center justify-between p-4 border-b border-gray-100 dark:border-gray-700">
                      <h3 className="font-bold text-gray-900 dark:text-white">{t('notification.title')}</h3>
                      {unreadCount > 0 && (
                        <span className="badge badge-active">{unreadCount} جديد</span>
                      )}
                    </div>
                    <div className="max-h-72 overflow-y-auto">
                      {notifications.length > 0 ? (
                        notifications.map(notif => (
                          <div key={notif.id} className="p-4 border-b border-gray-50 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 cursor-pointer transition-colors">
                            <p className="text-sm text-gray-700 dark:text-gray-300">{notif.message}</p>
                          </div>
                        ))
                      ) : (
                        <div className="flex flex-col items-center justify-center py-8 text-gray-400">
                          <FiBell size={32} className="mb-2 opacity-40" />
                          <p className="text-sm">{t('notification.noNotifications')}</p>
                        </div>
                      )}
                    </div>
                    <div className="p-3 border-t border-gray-100 dark:border-gray-700 text-center">
                      <Link to="/notifications" className="text-sm font-semibold text-indigo-600 hover:text-indigo-700" onClick={() => setShowNotifications(false)}>
                        {t('notification.viewAll')}
                      </Link>
                    </div>
                  </div>
                )}
              </div>

              {/* Avatar */}
              <Link to="/profile" className="flex items-center gap-2 pr-2">
                {user?.profilePicture ? (
                  <img src={`http://localhost:5000${user.profilePicture}`} className="w-9 h-9 rounded-xl object-cover ring-2 ring-indigo-200 dark:ring-indigo-700" />
                ) : (
                  <div className="w-9 h-9 bg-gradient-to-br from-indigo-500 to-violet-600 rounded-xl flex items-center justify-center text-white font-bold text-sm shadow-md shadow-indigo-500/30">
                    {user?.fullName?.[0]?.toUpperCase() || 'U'}
                  </div>
                )}
              </Link>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-4 lg:p-8 animate-fade-in">
          {children}
        </main>

        {/* Footer */}
        <footer className="py-4 text-center text-xs text-gray-400 dark:text-gray-600 border-t border-gray-100 dark:border-gray-800">
          © {new Date().getFullYear()} {t('common.appName')} · {t('common.rights')}
        </footer>
      </div>
    </div>
  );
};

export default Layout;

import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuthStore } from '../store/authStore';
import api from '../services/api';
import socket from '../services/socket';
import { Project, Task, User, Comment, File as ProjectFile } from '../types';
import toast from 'react-hot-toast';
import { 
  FiEdit, FiTrash2, FiPlus, FiDownload, FiUpload, 
  FiX, FiCalendar, FiUsers, FiFileText, FiMessageSquare,
  FiBarChart2, FiCheckCircle, FiClock, FiAlertCircle, FiPlay,
  FiFolder
} from 'react-icons/fi';
import FileUploader from '../components/FileUploader';
import Discussions from '../components/Discussions';
import Skeleton from '../components/Skeleton';

const ProjectDetails = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { user } = useAuthStore();
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'tasks' | 'members' | 'files' | 'comments' | 'discussions' | 'reports'>('overview');

  // بيانات للمهام
  const [tasks, setTasks] = useState<Task[]>([]);
  const [members, setMembers] = useState<User[]>([]);
  const [files, setFiles] = useState<ProjectFile[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [uploading, setUploading] = useState(false);
  const [newComment, setNewComment] = useState('');

  // حالة إضافة مهمة
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    priority: 'medium',
    dueDate: '',
    assigneeId: ''
  });

  // حالة إضافة عضو
  const [showAddMember, setShowAddMember] = useState(false);
  const [availableUsers, setAvailableUsers] = useState<User[]>([]);
  const [selectedUserId, setSelectedUserId] = useState('');

  // حالة التبويب الحالي للمهام (حسب الحالة)
  const [taskStatusTab, setTaskStatusTab] = useState<'not_started' | 'in_progress' | 'completed' | 'overdue'>('not_started');

  useEffect(() => {
    if (id) fetchProject();
  }, [id]);

  const fetchProject = async () => {
    try {
      const res = await api.get(`/projects/${id}`);
      setProject(res.data);
      setTasks(res.data.tasks || []);
      setMembers(res.data.members?.map((m: any) => m.user) || []);
      setComments(res.data.comments || []);
      setFiles(res.data.files || []);
    } catch {
      toast.error(t('project.fetchError'));
      navigate('/projects');
    } finally {
      setLoading(false);
    }
  };

  // WebSocket للتحديث الفوري
  useEffect(() => {
    if (!id) return;
    socket.emit('join-project', id);

    const handleTaskCreated = (task: Task) => {
      if (task.projectId === parseInt(id)) {
        setTasks(prev => [...prev, task]);
        toast.success(t('task.createdNotification'));
      }
    };
    const handleTaskUpdated = (task: Task) => {
      if (task.projectId === parseInt(id)) {
        setTasks(prev => prev.map(t => t.id === task.id ? task : t));
      }
    };
    const handleTaskStatusChanged = ({ id: taskId, status }: { id: number; status: string }) => {
      setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: status as any } : t));
    };
    const handleTaskDeleted = ({ id: taskId }: { id: number }) => {
      setTasks(prev => prev.filter(t => t.id !== taskId));
    };
    const handleCommentAdded = (comment: Comment) => {
      if (comment.projectId === parseInt(id)) setComments(prev => [comment, ...prev]);
    };
    const handleFileUploaded = (file: ProjectFile) => {
      if (file.projectId === parseInt(id)) setFiles(prev => [...prev, file]);
    };

    socket.on('taskCreated', handleTaskCreated);
    socket.on('taskUpdated', handleTaskUpdated);
    socket.on('taskStatusChanged', handleTaskStatusChanged);
    socket.on('taskDeleted', handleTaskDeleted);
    socket.on('commentAdded', handleCommentAdded);
    socket.on('fileUploaded', handleFileUploaded);

    return () => {
      socket.off('taskCreated', handleTaskCreated);
      socket.off('taskUpdated', handleTaskUpdated);
      socket.off('taskStatusChanged', handleTaskStatusChanged);
      socket.off('taskDeleted', handleTaskDeleted);
      socket.off('commentAdded', handleCommentAdded);
      socket.off('fileUploaded', handleFileUploaded);
    };
  }, [id]);

  // جلب المستخدمين المتاحين للإضافة
  useEffect(() => {
    if (showAddMember && (user?.role === 'admin' || user?.role === 'project_manager')) {
      const fetchAvailable = async () => {
        try {
          const res = await api.get('/users');
          setAvailableUsers(res.data.filter((u: User) => !members.some(m => m.id === u.id)));
        } catch {
          toast.error(t('member.fetchError'));
        }
      };
      fetchAvailable();
    }
  }, [showAddMember, members, user]);

  // إضافة مهمة جديدة
  const handleAddTask = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        ...newTask,
        assigneeId: newTask.assigneeId ? parseInt(newTask.assigneeId) : null
      };
      const res = await api.post(`/projects/${id}/tasks`, payload);
      setTasks(prev => [...prev, res.data]);
      setShowTaskModal(false);
      setNewTask({ title: '', description: '', priority: 'medium', dueDate: '', assigneeId: '' });
      toast.success(t('task.addSuccess'));
    } catch {
      toast.error(t('task.addError'));
    }
  };

  // تغيير حالة مهمة
  const handleStatusChange = async (taskId: number, newStatus: string) => {
  try {
    await api.patch(`/tasks/${taskId}/status`, { status: newStatus });
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: newStatus as any } : t));
    toast.success(t('task.statusUpdateSuccess'));
  } catch (error: any) {
    console.error('Status change error:', error.response?.data || error.message);
    toast.error(error.response?.data?.message || t('task.statusUpdateError'));
  }
};

  // حذف مهمة
  const handleDeleteTask = async (taskId: number) => {
    if (!confirm(t('common.confirmDelete'))) return;
    try {
      await api.delete(`/tasks/${taskId}`);
      setTasks(prev => prev.filter(t => t.id !== taskId));
      toast.success(t('task.deleteSuccess'));
    } catch {
      toast.error(t('task.deleteError'));
    }
  };

  // إضافة عضو
  const handleAddMember = async () => {
    if (!selectedUserId) return;
    try {
      await api.post(`/projects/${id}/members`, { userId: parseInt(selectedUserId) });
      const newMember = availableUsers.find(u => u.id === parseInt(selectedUserId));
      if (newMember) {
        setMembers(prev => [...prev, newMember]);
        setAvailableUsers(prev => prev.filter(u => u.id !== parseInt(selectedUserId)));
      }
      setShowAddMember(false);
      setSelectedUserId('');
      toast.success(t('member.addSuccess'));
    } catch {
      toast.error(t('member.addError'));
    }
  };

  // إزالة عضو
  const handleRemoveMember = async (userId: number) => {
    if (!confirm(t('common.confirmDelete'))) return;
    try {
      await api.delete(`/projects/${id}/members/${userId}`);
      setMembers(prev => prev.filter(m => m.id !== userId));
      toast.success(t('member.removeSuccess'));
    } catch {
      toast.error(t('member.removeError'));
    }
  };

  // رفع ملف
  const handleFileUpload = async (files: File[]) => {
    setUploading(true);
    const formData = new FormData();
    files.forEach(f => formData.append('files', f));
    try {
      const res = await api.post(`/projects/${id}/files`, formData);
      setFiles(prev => [...prev, ...res.data]);
      toast.success(t('file.uploadSuccess'));
    } catch {
      toast.error(t('file.uploadError'));
    } finally {
      setUploading(false);
    }
  };

  // حذف ملف
  const handleDeleteFile = async (fileId: number) => {
    if (!confirm(t('common.confirmDelete'))) return;
    try {
      await api.delete(`/files/${fileId}`);
      setFiles(prev => prev.filter(f => f.id !== fileId));
      toast.success(t('file.deleteSuccess'));
    } catch {
      toast.error(t('file.deleteError'));
    }
  };

  // إضافة تعليق
  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    try {
      const res = await api.post(`/projects/${id}/comments`, { content: newComment });
      setComments(prev => [res.data, ...prev]);
      setNewComment('');
      toast.success(t('comment.addSuccess'));
    } catch {
      toast.error(t('comment.addError'));
    }
  };

  // حذف تعليق
  const handleDeleteComment = async (commentId: number) => {
    if (!confirm(t('common.confirmDelete'))) return;
    try {
      await api.delete(`/comments/${commentId}`);
      setComments(prev => prev.filter(c => c.id !== commentId));
      toast.success(t('comment.deleteSuccess'));
    } catch {
      toast.error(t('comment.deleteError'));
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-32 w-full rounded-xl" />
        <div className="flex gap-2 border-b overflow-x-auto">
          {[...Array(7)].map((_, i) => <Skeleton key={i} className="h-10 w-24" />)}
        </div>
        <Skeleton className="h-64 w-full rounded-xl" />
      </div>
    );
  }

  if (!project) return <div className="text-center py-10">{t('project.notFound')}</div>;

  const isManager = user?.role === 'admin' || project.createdBy === user?.id;

  const tabs = [
    { id: 'overview', label: t('common.overview'), icon: FiFolder },
    { id: 'tasks', label: t('common.tasks'), icon: FiCheckCircle },
    { id: 'members', label: t('common.members'), icon: FiUsers },
    { id: 'files', label: t('common.files'), icon: FiUpload },
    { id: 'comments', label: t('common.comments'), icon: FiMessageSquare },
    { id: 'discussions', label: t('discussions.title'), icon: FiMessageSquare },
    { id: 'reports', label: t('common.reports'), icon: FiBarChart2 },
  ];

  // تبويبات حالات المهام (داخل تبويب المهام)
  const taskStatusTabs = [
    { id: 'not_started', label: t('task.not_started'), icon: FiClock },
    { id: 'in_progress', label: t('task.in_progress'), icon: FiPlay },
    { id: 'completed', label: t('task.completed'), icon: FiCheckCircle },
    { id: 'overdue', label: t('task.overdue'), icon: FiAlertCircle },
  ];

  return (
    <div className="space-y-6">
      {/* رأس المشروع */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-100 dark:border-gray-700">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{project.name}</h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">{project.description}</p>
            <div className="flex flex-wrap gap-4 mt-4 text-sm">
              <span className="flex items-center gap-1 text-gray-500">
                <FiCalendar /> {t('project.startDate')}: {new Date(project.startDate).toLocaleDateString()}
              </span>
              {project.endDate && (
                <span className="flex items-center gap-1 text-gray-500">
                  <FiCalendar /> {t('project.endDate')}: {new Date(project.endDate).toLocaleDateString()}
                </span>
              )}
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                project.status === 'active' ? 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-200' :
                project.status === 'completed' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-200' :
                'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-200'
              }`}>
                {project.status === 'active' ? t('project.active') :
                 project.status === 'completed' ? t('project.completed') : t('project.suspended')}
              </span>
            </div>
          </div>
          {isManager && (
            <div className="flex gap-2">
              <Link to={`/projects/${id}/edit`} className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg">
                <FiEdit size={20} />
              </Link>
              <button
                onClick={async () => {
                  if (!confirm(t('common.confirmDelete'))) return;
                  try {
                    await api.delete(`/projects/${id}`);
                    toast.success(t('project.deleteSuccess'));
                    navigate('/projects');
                  } catch {
                    toast.error(t('project.deleteError'));
                  }
                }}
                className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg"
              >
                <FiTrash2 size={20} />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* تبويبات الصفحة الرئيسية */}
      <div className="border-b border-gray-200 dark:border-gray-700 overflow-x-auto">
        <nav className="flex space-x-8 space-x-reverse min-w-max px-1">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-2 px-1 border-b-2 font-medium text-sm flex items-center gap-2 whitespace-nowrap transition ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              <tab.icon size={18} />
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* محتوى التبويبات */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-100 dark:border-gray-700">
        {activeTab === 'overview' && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">{t('project.overview')}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
                <p className="text-sm text-gray-500">{t('project.startDate')}</p>
                <p className="font-medium">{new Date(project.startDate).toLocaleDateString()}</p>
              </div>
              {project.endDate && (
                <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500">{t('project.endDate')}</p>
                  <p className="font-medium">{new Date(project.endDate).toLocaleDateString()}</p>
                </div>
              )}
              <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
                <p className="text-sm text-gray-500">{t('common.tasks')}</p>
                <p className="font-medium">{tasks.length}</p>
              </div>
              <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
                <p className="text-sm text-gray-500">{t('common.members')}</p>
                <p className="font-medium">{members.length}</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'tasks' && (
          <div className="space-y-4">
            {/* رأس المهام مع زر الإضافة */}
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold">{t('task.title')}</h2>
              {isManager && (
                <button
                  onClick={() => setShowTaskModal(true)}
                  className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition"
                >
                  <FiPlus size={16} /> {t('task.newTask')}
                </button>
              )}
            </div>

            {/* مودال إضافة مهمة */}
            {showTaskModal && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-md w-full p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold">{t('task.newTask')}</h3>
                    <button onClick={() => setShowTaskModal(false)} className="text-gray-500 hover:text-gray-700">
                      <FiX size={24} />
                    </button>
                  </div>
                  <form onSubmit={handleAddTask} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">{t('task.taskTitle')}</label>
                      <input
                        type="text"
                        value={newTask.title}
                        onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                        className="w-full p-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">{t('task.description')}</label>
                      <textarea
                        rows={3}
                        value={newTask.description}
                        onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                        className="w-full p-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">{t('task.priority')}</label>
                        <select
                          value={newTask.priority}
                          onChange={(e) => setNewTask({ ...newTask, priority: e.target.value })}
                          className="w-full p-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg"
                        >
                          <option value="high">{t('task.high')}</option>
                          <option value="medium">{t('task.medium')}</option>
                          <option value="low">{t('task.low')}</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">{t('task.dueDate')}</label>
                        <input
                          type="date"
                          value={newTask.dueDate}
                          onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })}
                          className="w-full p-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">{t('task.assignee')}</label>
                      <select
                        value={newTask.assigneeId}
                        onChange={(e) => setNewTask({ ...newTask, assigneeId: e.target.value })}
                        className="w-full p-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg"
                      >
                        <option value="">{t('task.unassigned')}</option>
                        {members.map(m => (
                          <option key={m.id} value={m.id}>{m.fullName}</option>
                        ))}
                      </select>
                    </div>
                    <div className="flex gap-2 pt-4">
                      <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                        {t('common.add')}
                      </button>
                      <button type="button" onClick={() => setShowTaskModal(false)} className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-100">
                        {t('common.cancel')}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {/* تبويبات حالات المهام */}
            <div className="border-b border-gray-200 dark:border-gray-700">
              <nav className="flex space-x-4 space-x-reverse">
                {taskStatusTabs.map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setTaskStatusTab(tab.id)}
                    className={`py-2 px-3 border-b-2 font-medium text-sm flex items-center gap-2 transition ${
                      taskStatusTab === tab.id
                        ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                        : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                    }`}
                  >
                    <tab.icon size={16} />
                    {tab.label}
                  </button>
                ))}
              </nav>
            </div>

            {/* عرض المهام حسب الحالة المختارة */}
            <div className="space-y-3">
              {tasks.filter(t => t.status === taskStatusTab).length === 0 ? (
                <p className="text-center text-gray-500 py-4">{t('common.noData')}</p>
              ) : (
                tasks.filter(t => t.status === taskStatusTab).map(task => (
                  <div key={task.id} className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900 dark:text-white">{task.title}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{task.description}</p>
                        <div className="flex flex-wrap gap-3 mt-2 text-xs text-gray-500">
                          <span className={`px-2 py-0.5 rounded-full ${
                            task.priority === 'high' ? 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-200' :
                            task.priority === 'medium' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-200' :
                            'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-200'
                          }`}>
                            {t(`task.${task.priority}`)}
                          </span>
                          <span>{t('task.assignee')}: {task.assignee?.fullName || t('task.unassigned')}</span>
                          {task.dueDate && (
                            <span className="flex items-center gap-1">
                              <FiClock size={12} /> {new Date(task.dueDate).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {/* قائمة منسدلة لتغيير الحالة */}
                        <select
                          value={task.status}
                          onChange={(e) => handleStatusChange(task.id, e.target.value)}
                          className="p-1.5 text-sm border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg"
                        >
                          <option value="not_started">{t('task.not_started')}</option>
                          <option value="in_progress">{t('task.in_progress')}</option>
                          <option value="completed">{t('task.completed')}</option>
                          <option value="overdue">{t('task.overdue')}</option>
                        </select>
                        {/* زر حذف (للمدير فقط) */}
                        {isManager && (
                          <button onClick={() => handleDeleteTask(task.id)} className="p-2 text-red-600 hover:bg-red-100 dark:hover:bg-red-900/30 rounded-lg">
                            <FiTrash2 size={18} />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTab === 'members' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold">{t('member.title')}</h2>
              {isManager && (
                <button
                  onClick={() => setShowAddMember(!showAddMember)}
                  className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition"
                >
                  <FiPlus size={16} /> {t('member.addMember')}
                </button>
              )}
            </div>

            {showAddMember && (
              <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg flex flex-col sm:flex-row gap-2">
                <select
                  value={selectedUserId}
                  onChange={(e) => setSelectedUserId(e.target.value)}
                  className="flex-1 p-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg"
                >
                  <option value="">{t('member.selectUser')}</option>
                  {availableUsers.map(u => (
                    <option key={u.id} value={u.id}>{u.fullName} ({u.username})</option>
                  ))}
                </select>
                <div className="flex gap-2">
                  <button onClick={handleAddMember} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                    {t('common.add')}
                  </button>
                  <button onClick={() => setShowAddMember(false)} className="px-4 py-2 bg-gray-200 dark:bg-gray-600 rounded-lg hover:bg-gray-300">
                    {t('common.cancel')}
                  </button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {members.map(member => (
                <div key={member.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                  <div className="flex items-center gap-3">
                    {member.profilePicture ? (
                      <img src={`http://localhost:5000${member.profilePicture}`} className="w-10 h-10 rounded-full object-cover" />
                    ) : (
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white font-bold">
                        {member.fullName[0]}
                      </div>
                    )}
                    <div>
                      <p className="font-medium">{member.fullName}</p>
                      <p className="text-xs text-gray-500">{member.username}</p>
                    </div>
                  </div>
                  {member.id === project.createdBy && (
                    <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">{t('member.projectManager')}</span>
                  )}
                  {isManager && member.id !== project.createdBy && (
                    <button onClick={() => handleRemoveMember(member.id)} className="text-red-500 hover:text-red-600">
                      <FiTrash2 size={16} />
                    </button>
                  )}
                </div>
              ))}
              {members.length === 0 && <p className="text-center text-gray-500 col-span-full py-4">{t('member.noMembers')}</p>}
            </div>
          </div>
        )}

        {activeTab === 'files' && (
          <div className="space-y-4">
            <FileUploader onUpload={handleFileUpload} uploading={uploading} />
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {files.map(file => (
                <div key={file.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                  <div>
                    <p className="font-medium text-sm">{file.fileName}</p>
                    <p className="text-xs text-gray-500">{(file.size / 1024).toFixed(2)} KB</p>
                  </div>
                  <div className="flex gap-2">
                    <a href={`http://localhost:5000/api/files/${file.id}/download`} className="p-1.5 text-blue-600 hover:bg-blue-100 rounded">
                      <FiDownload size={16} />
                    </a>
                    {(user?.id === file.uploadedBy || isManager) && (
                      <button onClick={() => handleDeleteFile(file.id)} className="p-1.5 text-red-600 hover:bg-red-100 rounded">
                        <FiTrash2 size={16} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
              {files.length === 0 && <p className="text-center text-gray-500 col-span-full py-4">{t('file.noFiles')}</p>}
            </div>
          </div>
        )}

        {activeTab === 'comments' && (
          <div className="space-y-4">
            <form onSubmit={handleAddComment} className="flex gap-2">
              <input
                type="text"
                placeholder={t('comment.addComment')}
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                className="flex-1 p-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg"
              />
              <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                {t('comment.post')}
              </button>
            </form>
            <div className="space-y-3">
              {comments.map(comment => (
                <div key={comment.id} className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-2">
                      {comment.user?.profilePicture ? (
                        <img src={`http://localhost:5000${comment.user.profilePicture}`} className="w-6 h-6 rounded-full" />
                      ) : (
                        <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white text-xs">
                          {comment.user?.fullName?.[0] || '?'}
                        </div>
                      )}
                      <span className="font-medium text-sm">{comment.user?.fullName}</span>
                      <span className="text-xs text-gray-500">{new Date(comment.createdAt).toLocaleString()}</span>
                    </div>
                    {(user?.id === comment.userId || isManager) && (
                      <button onClick={() => handleDeleteComment(comment.id)} className="text-red-500 hover:text-red-600">
                        <FiTrash2 size={16} />
                      </button>
                    )}
                  </div>
                  <p className="mt-2 text-sm">{comment.content}</p>
                </div>
              ))}
              {comments.length === 0 && <p className="text-center text-gray-500 py-4">{t('comment.noComments')}</p>}
            </div>
          </div>
        )}

        {activeTab === 'discussions' && <Discussions projectId={id!} />}

        {activeTab === 'reports' && (
          <div className="space-y-6">
            <h2 className="text-lg font-semibold">{t('report.title')}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                <p className="text-sm text-blue-600 dark:text-blue-400">{t('report.totalTasks')}</p>
                <p className="text-2xl font-bold">{tasks.length}</p>
              </div>
              <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
                <p className="text-sm text-green-600 dark:text-green-400">{t('report.completedTasks')}</p>
                <p className="text-2xl font-bold">{tasks.filter(t => t.status === 'completed').length}</p>
              </div>
              <div className="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg">
                <p className="text-sm text-yellow-600 dark:text-yellow-400">{t('report.overdueTasks')}</p>
                <p className="text-2xl font-bold">{tasks.filter(t => t.status === 'overdue').length}</p>
              </div>
            </div>

            {/* توزيع المهام حسب الحالة */}
            <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
              <h3 className="font-medium mb-3">{t('report.tasksByStatus')}</h3>
              <div className="space-y-2">
                {['not_started', 'in_progress', 'completed', 'overdue'].map(status => {
                  const count = tasks.filter(t => t.status === status).length;
                  const percentage = tasks.length ? Math.round((count / tasks.length) * 100) : 0;
                  return (
                    <div key={status}>
                      <div className="flex justify-between text-sm mb-1">
                        <span>{t(`task.${status}`)}</span>
                        <span>{count} {t('report.tasksCount')} ({percentage}%)</span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${
                            status === 'not_started' ? 'bg-gray-400' :
                            status === 'in_progress' ? 'bg-blue-500' :
                            status === 'completed' ? 'bg-green-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* أداء الأعضاء */}
            <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
              <h3 className="font-medium mb-3">{t('report.memberPerformance')}</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead>
                    <tr className="text-sm text-gray-500 border-b">
                      <th className="py-2 text-right">{t('common.member')}</th>
                      <th className="py-2 text-right">{t('report.totalTasks')}</th>
                      <th className="py-2 text-right">{t('report.completedTasks')}</th>
                      <th className="py-2 text-right">{t('report.percentage')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {members.map(member => {
                      const memberTasks = tasks.filter(t => t.assigneeId === member.id);
                      const completed = memberTasks.filter(t => t.status === 'completed').length;
                      const total = memberTasks.length;
                      const percentage = total ? Math.round((completed / total) * 100) : 0;
                      return (
                        <tr key={member.id} className="border-b">
                          <td className="py-2">{member.fullName}</td>
                          <td className="py-2">{total}</td>
                          <td className="py-2">{completed}</td>
                          <td className="py-2">
                            <div className="flex items-center gap-2">
                              <span className="w-12 text-sm">{percentage}%</span>
                              <div className="w-20 bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                                <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${percentage}%` }} />
                              </div>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectDetails;
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import api from '../services/api';
import { User } from '../types';
import toast from 'react-hot-toast';
import { FiToggleLeft, FiToggleRight, FiSearch, FiTrash2 } from 'react-icons/fi';
import Skeleton from '../components/Skeleton';

const Users = () => {
  const { t } = useTranslation();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const res = await api.get('/users');
      setUsers(res.data);
    } catch (error: any) {
      console.error('Fetch users error:', error.response?.data || error.message);
      toast.error(t('users.fetchError'));
    } finally {
      setLoading(false);
    }
  };

  const handleToggleActive = async (userId: number) => {
    try {
      // نرسل طلب التبديل ونتوقع استجابة تحتوي على الحالة الجديدة
      const res = await api.patch(`/users/${userId}/toggle-active`);
      const { isActive } = res.data; // يفترض أن الـ API يعيد { id, isActive }
      // تحديث الحالة محلياً
      setUsers(prev => prev.map(u => u.id === userId ? { ...u, isActive } : u));
      toast.success(t('users.toggleSuccess'));
    } catch (error: any) {
      console.error('Toggle error:', error.response?.data || error.message);
      toast.error(error.response?.data?.message || t('users.toggleError'));
    }
  };

  const handleDelete = async (userId: number) => {
    if (!confirm(t('common.confirmDelete'))) return;
    try {
      await api.delete(`/users/${userId}`);
      setUsers(prev => prev.filter(u => u.id !== userId));
      toast.success(t('users.deleteSuccess'));
    } catch (error: any) {
      console.error('Delete error:', error.response?.data || error.message);
      toast.error(error.response?.data?.message || t('users.deleteError'));
    }
  };

  const handleRoleChange = async (userId: number, newRole: string) => {
    try {
      await api.put(`/users/${userId}`, { role: newRole });
      setUsers(prev => prev.map(u => u.id === userId ? { ...u, role: newRole as any } : u));
      toast.success(t('users.roleSuccess'));
    } catch (error: any) {
      console.error('Role change error:', error.response?.data || error.message);
      toast.error(error.response?.data?.message || t('users.roleError'));
    }
  };

  const filtered = users.filter(u =>
    u.fullName.toLowerCase().includes(search.toLowerCase()) ||
    u.username.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) return <Skeleton className="h-64 w-full rounded-xl" />;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white">{t('users.title')}</h1>

      <div className="relative max-w-md">
        <FiSearch className="absolute right-3 top-3 text-gray-400" />
        <input
          type="text"
          placeholder={t('common.search')}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pr-10 pl-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg"
        />
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-800">
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">{t('common.user')}</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">{t('common.email')}</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">{t('member.role')}</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">{t('common.status')}</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">{t('common.actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {filtered.map(user => (
                <tr key={user.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-3">
                      {user.profilePicture ? (
                        <img src={`http://localhost:5000${user.profilePicture}`} className="w-8 h-8 rounded-full object-cover" />
                      ) : (
                        <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center text-white text-sm">
                          {user.fullName[0]}
                        </div>
                      )}
                      <div>
                        <p className="font-medium">{user.fullName}</p>
                        <p className="text-xs text-gray-500">@{user.username}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-400">{user.email}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <select
                      value={user.role}
                      onChange={(e) => handleRoleChange(user.id, e.target.value)}
                      className="p-1 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded text-sm"
                    >
                      <option value="team_member">{t('member.team_member')}</option>
                      <option value="project_manager">{t('member.project_manager')}</option>
                      <option value="admin">{t('member.admin')}</option>
                    </select>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs rounded-full ${user.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                      {user.isActive ? t('common.active') : t('common.inactive')}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleToggleActive(user.id)}
                        className="text-blue-600 hover:text-blue-800"
                        title={user.isActive ? t('common.deactivate') : t('common.activate')}
                      >
                        {user.isActive ? <FiToggleRight size={20} /> : <FiToggleLeft size={20} />}
                      </button>
                      <button onClick={() => handleDelete(user.id)} className="text-red-600 hover:text-red-800">
                        <FiTrash2 size={20} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <p className="text-center text-gray-500 py-4">{t('users.noUsers')}</p>
        )}
      </div>
    </div>
  );
};

export default Users;
import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import { useAuthStore } from './store/authStore';
import socket from './services/socket';
import Layout from './components/Layout';
import PrivateRoute from './components/PrivateRoute';
import Login from './pages/Login';
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';
import Dashboard from './pages/Dashboard';
import Projects from './pages/Projects';
import ProjectForm from './pages/ProjectForm';
import ProjectDetails from './pages/ProjectDetails';
import Profile from './pages/Profile';
import Users from './pages/Users';
import ActivityLog from './pages/ActivityLog';
import Notifications from './pages/Notifications';
import toast from 'react-hot-toast';

function App() {
  const { token, user, logout } = useAuthStore();
  const { t } = useTranslation();

  // الاستماع لحدث تعطيل المستخدم من WebSocket
  useEffect(() => {
    const handleUserDeactivated = (data: { message: string }) => {
      toast.error(data.message || t('auth.accountDeactivated'));
      logout(); // تسجيل الخروج فوراً
    };

    socket.on('userDeactivated', handleUserDeactivated);

    // تسجيل المستخدم الحالي في غرفته الخاصة
    if (user) {
      socket.emit('register-user', user.id);
    }

    return () => {
      socket.off('userDeactivated', handleUserDeactivated);
    };
  }, [user, logout, t]);

  return (
    <BrowserRouter>
      <Toaster position="top-left" reverseOrder={false} />
      <Routes>
        {/* صفحات عامة */}
        <Route path="/login" element={token ? <Navigate to="/" /> : <Login />} />
        <Route path="/register" element={token ? <Navigate to="/" /> : <Register />} />
        <Route path="/forgot-password" element={token ? <Navigate to="/" /> : <ForgotPassword />} />
        <Route path="/reset-password" element={token ? <Navigate to="/" /> : <ResetPassword />} />

        {/* صفحات محمية */}
        <Route path="/" element={
          <PrivateRoute>
            <Layout>
              <Dashboard />
            </Layout>
          </PrivateRoute>
        } />
        <Route path="/profile" element={
          <PrivateRoute>
            <Layout>
              <Profile />
            </Layout>
          </PrivateRoute>
        } />
        <Route path="/users" element={
          <PrivateRoute requiredRole={['admin']}>
            <Layout>
              <Users />
            </Layout>
          </PrivateRoute>
        } />
        <Route path="/projects" element={
          <PrivateRoute>
            <Layout>
              <Projects />
            </Layout>
          </PrivateRoute>
        } />
        <Route path="/projects/new" element={
          <PrivateRoute requiredRole={['admin', 'project_manager']}>
            <Layout>
              <ProjectForm />
            </Layout>
          </PrivateRoute>
        } />
        <Route path="/projects/:id/edit" element={
          <PrivateRoute requiredRole={['admin', 'project_manager']}>
            <Layout>
              <ProjectForm />
            </Layout>
          </PrivateRoute>
        } />
        <Route path="/projects/:id" element={
          <PrivateRoute>
            <Layout>
              <ProjectDetails />
            </Layout>
          </PrivateRoute>
        } />
        <Route path="/activities" element={
          <PrivateRoute>
            <Layout>
              <ActivityLog />
            </Layout>
          </PrivateRoute>
        } />
        <Route path="/notifications" element={
          <PrivateRoute>
            <Layout>
              <Notifications />
            </Layout>
          </PrivateRoute>
        } />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
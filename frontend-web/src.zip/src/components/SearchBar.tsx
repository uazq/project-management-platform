import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import api from '../services/api';
import { FiSearch, FiX, FiFolder, FiCheckCircle } from 'react-icons/fi';

interface SearchResult {
  type: 'project' | 'task';
  id: number;
  title: string;
  description?: string;
  projectId?: number;
  projectName?: string;
}

const SearchBar = () => {
  const { t } = useTranslation();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowResults(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const fetchResults = async () => {
      if (query.length < 2) {
        setResults([]);
        return;
      }
      setLoading(true);
      try {
        const res = await api.get(`/search?q=${encodeURIComponent(query)}`);
        setResults(res.data);
      } catch {
        // silent
      } finally {
        setLoading(false);
      }
    };
    const timer = setTimeout(fetchResults, 300);
    return () => clearTimeout(timer);
  }, [query]);

  const handleSelect = (result: SearchResult) => {
    if (result.type === 'project') {
      navigate(`/projects/${result.id}`);
    } else {
      navigate(`/projects/${result.projectId}`);
    }
    setShowResults(false);
    setQuery('');
  };

  return (
    <div className="relative flex-1 max-w-md" ref={searchRef}>
      <div className="relative">
        <FiSearch className="absolute right-3 top-3 text-gray-400" />
        <input
          type="text"
          placeholder={t('common.search')}
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setShowResults(true);
          }}
          onFocus={() => setShowResults(true)}
          className="w-full pr-10 pl-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg"
        />
        {query && (
          <button onClick={() => setQuery('')} className="absolute left-2 top-2.5 text-gray-400 hover:text-gray-600">
            <FiX size={18} />
          </button>
        )}
      </div>
      {showResults && (query.length > 0 || results.length > 0) && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 z-50 max-h-96 overflow-y-auto">
          {loading ? (
            <div className="p-4 text-center text-gray-500">{t('common.loading')}</div>
          ) : results.length > 0 ? (
            <div className="py-2">
              {results.map((r, i) => (
                <div
                  key={i}
                  onClick={() => handleSelect(r)}
                  className="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer flex items-start gap-3"
                >
                  {r.type === 'project' ? (
                    <FiFolder className="mt-1 text-blue-500" />
                  ) : (
                    <FiCheckCircle className="mt-1 text-green-500" />
                  )}
                  <div>
                    <p className="font-medium">{r.title}</p>
                    <p className="text-xs text-gray-500">
                      {r.type === 'project' ? t('common.projects') : t('common.tasks')}
                      {r.projectName && ` • ${r.projectName}`}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : query.length >= 2 ? (
            <div className="p-4 text-center text-gray-500">{t('common.noData')}</div>
          ) : null}
        </div>
      )}
    </div>
  );
};

export default SearchBar;
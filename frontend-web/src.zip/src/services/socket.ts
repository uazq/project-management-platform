import { io } from 'socket.io-client';
import { useAuthStore } from '../store/authStore';

const socket = io(import.meta.env.VITE_API_URL?.replace('/api', '') || 'http://localhost:5000');

// بعد الاتصال، سجل المستخدم الحالي (إذا كان موجوداً)
const user = useAuthStore.getState().user;
if (user) {
  socket.emit('register-user', user.id);
}

// استمع لتغييرات حالة المستخدم لتحديث التسجيل
useAuthStore.subscribe((state) => {
  if (state.user) {
    socket.emit('register-user', state.user.id);
  }
});

export default socket;
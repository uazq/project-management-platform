import { create } from 'zustand';
import { User } from '../types';
import { login as apiLogin, register as apiRegister } from '../services/auth';
import toast from 'react-hot-toast';

interface AuthState {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  register: (data: { fullName: string; username: string; email: string; password: string }) => Promise<void>;
  logout: () => void;
  setUser: (user: User) => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: JSON.parse(localStorage.getItem('user') || 'null'),
  token: localStorage.getItem('token'),
  isLoading: false,

  login: async (username, password) => {
    set({ isLoading: true });
    try {
      const response = await apiLogin({ username, password });
      localStorage.setItem('token', response.token);
      localStorage.setItem('user', JSON.stringify(response.user));
      set({ user: response.user, token: response.token, isLoading: false });
      toast.success('تم تسجيل الدخول بنجاح');
    } catch (error) {
      set({ isLoading: false });
      // لا نحتاج لفعل أي شيء هنا لأن interceptor يعالج الأخطاء
    }
  },

  register: async (data) => {
    set({ isLoading: true });
    try {
      const response = await apiRegister(data);
      localStorage.setItem('token', response.token);
      localStorage.setItem('user', JSON.stringify(response.user));
      set({ user: response.user, token: response.token, isLoading: false });
      toast.success('تم إنشاء الحساب بنجاح');
    } catch (error) {
      set({ isLoading: false });
    }
  },

  logout: () => {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  set({ user: null, token: null });
  socket.emit('leave-all-rooms'); // يمكنك إضافة هذا إذا أردت
  toast.success(t('auth.logoutSuccess'));
},

  setUser: (user) => {
    localStorage.setItem('user', JSON.stringify(user));
    set({ user });
  }
}));